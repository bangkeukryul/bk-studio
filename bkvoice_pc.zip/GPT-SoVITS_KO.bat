@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "runtime\python.exe" (
  echo  runtime\python.exe not found. Put this file in the GPT-SoVITS folder.
  pause
  exit /b
)
set "PATH=%~dp0runtime;%PATH%"
runtime\python.exe -I webui.py ko_KR
pause
