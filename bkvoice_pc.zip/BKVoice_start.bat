@echo off
chcp 65001 >nul
cd /d "%~dp0"
title BKVoice
if not exist "runtime\python.exe" (
  echo.
  echo  [BKVoice] runtime\python.exe not found.
  echo  Copy bkvoice.py and this file into the GPT-SoVITS folder
  echo  ^(the folder that has go-webui.bat^), then run again.
  echo.
  pause
  exit /b
)
set "PATH=%~dp0runtime;%PATH%"
runtime\python.exe bkvoice.py
pause
