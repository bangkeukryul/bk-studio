﻿BK보이스 v1.1 — 내 PC의 '내 목소리'를 휴대폰 BK스튜디오로 보내 주는 프로그램
================================================================

[설치]
1. 이 폴더의 파일 4개를 GPT-SoVITS 폴더(go-webui.bat 이 있는 곳, 예: C:\GPT-SoVITS)에 복사하세요.
     bkvoice.py / BKVoice_start.bat / GPT-SoVITS_KO.bat / README_BKVoice.txt
2. BKVoice_start.bat 을 더블클릭하세요.
   - 'Windows의 PC 보호' → 추가 정보 → 실행
   - 방화벽 창 → 개인·공용 모두 체크 → 액세스 허용
3. 검은 창에 나온 PIN 번호와 휴대폰 주소(http://192.168.x.x:9870)를 휴대폰 크롬에서 여세요.

[파일]
- BKVoice_start.bat   : BK보이스 켜기 (검은 창을 닫으면 꺼져요)
- GPT-SoVITS_KO.bat   : GPT-SoVITS 학습 화면을 한글로 켜기 (학습할 땐 BK보이스를 먼저 끄세요)
- bkvoice_data 폴더   : 설정·기준 음성(ref)·학습용 녹음(train)·만든 음성(out)이 저장돼요

[자세한 설명서]
https://bangkeukryul.github.io/bk-studio/guide.html

본인 목소리만 사용해 주세요. · BK Agent · 비케이
